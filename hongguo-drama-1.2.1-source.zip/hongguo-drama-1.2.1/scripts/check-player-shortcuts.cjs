// In-memory DOM propagation + real Player handlers. Native browser behavior also needs UI acceptance.
const assert = require('node:assert/strict');
const { mount } = require('./check-player-resume.cjs');

function target(tagName, { role = '', editable = false, menu = false, insidePlayer = true, playerControl = false } = {}) {
  return { tagName: tagName.toUpperCase(), isContentEditable: editable,
    closest(selectors) {
      return selectors.split(',').some(raw => {
        const selector = raw.trim();
        if (selector === tagName) return true;
        if (selector === '.player-container' && insidePlayer) return true;
        if (selector === '[data-player-control]' && playerControl) return true;
        if (selector === '[data-player-menu]' && menu) return true;
        if (selector.includes('[contenteditable') && editable) return true;
        const wantedRole = selector.match(/\[role=["']?([^\]"']+)["']?\]/)?.[1];
        return wantedRole === role || (menu && wantedRole === 'menu');
      }) ? this : null;
    },
  };
}

function press(ui, key, focused, extra = {}, targetAction) {
  ui.document.activeElement = focused;
  const init = { key, code: key === ' ' ? 'Space' : key, target: focused, ...extra };
  const down = ui.dispatchKey('keydown', init, targetAction);
  const up = ui.dispatchKey('keyup', init, targetAction);
  return { down, up };
}

async function ready() {
  const ui = mount({ local: true, episodeCount: 3 });
  await ui.flush(); ui.metadata(); ui.render();
  return ui;
}

(async () => {
  let failures = 0;
  const test = async (name, run) => {
    const ui = await ready();
    try { await run(ui); console.log(`PASS ${name}`); }
    catch (error) { failures++; console.error(`FAIL ${name}: ${error.message}`); }
    finally { ui.unmount(); }
  };

  await test('Space on focused video toggles once before control listeners, keyup and repeat', async ui => {
    const focused = target('video');
    const before = { ...ui.mediaCalls };
    let controlCalls = 0;
    const videoControlListener = event => {
      if (event.type !== 'keydown' || event.code !== 'Space' || event.defaultPrevented) return;
      controlCalls++;
      ui.media.paused ? ui.media.play() : ui.media.pause();
    };
    const { down } = press(ui, ' ', focused, {}, videoControlListener);
    assert.equal(ui.media.paused, true, 'one Space must leave a playing video paused');
    assert.equal(ui.mediaCalls.pause - before.pause, 1);
    assert.equal(ui.mediaCalls.play - before.play, 0, 'keyup must not restart video');
    assert.equal(controlCalls, 0, 'handled key must not reach another control handler');
    assert.equal(down.defaultPrevented, true);
    press(ui, ' ', focused, { repeat: true }, videoControlListener);
    assert.equal(ui.mediaCalls.pause - before.pause, 1);
    assert.equal(ui.mediaCalls.play - before.play, 0, 'holding Space must not repeatedly toggle');
    press(ui, ' ', focused, {}, videoControlListener);
    assert.equal(ui.media.paused, false, 'a second independent press resumes');
    assert.equal(ui.mediaCalls.play - before.play, 1);
  });

  await test('episode-button focus keeps Space and episode arrows usable without button activation', async ui => {
    ui.episode(2); await ui.flush(); ui.metadata(); ui.render();
    const focused = target('button');
    let clicks = 0;
    const { down, up } = press(ui, ' ', focused);
    // A button's default Space activation on keyup is cancelled by a cancelled keydown.
    if (!down.defaultPrevented && !up.defaultPrevented) { clicks++; ui.episode(2); }
    assert.equal(ui.media.paused, true, 'Space after clicking an episode must pause');
    assert.equal(clicks, 0, 'Space must not reactivate the focused episode button');
    const next = press(ui, 'ArrowDown', focused).down;
    assert.equal(next.defaultPrevented, true, 'episode change must prevent page scroll');
    await ui.flush(); assert.equal(ui.media.src, 'file:///mock-3.mp4');
    ui.metadata(); ui.render();
    press(ui, 'ArrowUp', focused); await ui.flush();
    assert.equal(ui.media.src, 'file:///mock-2.mp4');
    ui.metadata(); ui.render();
    press(ui, 'ArrowUp', focused, { repeat: true }); await ui.flush();
    assert.equal(ui.media.src, 'file:///mock-2.mp4', 'holding episode arrow must not skip another episode');
  });

  await test('left/right seek exactly five seconds and prevent scrolling, including unknown duration', async ui => {
    const focused = target('video');
    ui.media.currentTime = 40;
    assert.equal(press(ui, 'ArrowRight', focused).down.defaultPrevented, true);
    assert.equal(ui.media.currentTime, 45);
    assert.equal(press(ui, 'ArrowLeft', focused).down.defaultPrevented, true);
    assert.equal(ui.media.currentTime, 40);
    ui.media.duration = NaN;
    press(ui, 'ArrowRight', focused);
    assert.equal(ui.media.currentTime, 45, 'unknown duration must not reset playback to zero');
    ui.media.currentTime = 2;
    press(ui, 'ArrowLeft', focused); assert.equal(ui.media.currentTime, 0);
    ui.media.duration = 100; ui.media.currentTime = 98;
    press(ui, 'ArrowRight', focused); assert.equal(ui.media.currentTime, 100);
  });

  await test('inputs, editable content, menus and modified keys keep their own actions', async ui => {
    for (const focused of [target('input'), target('textarea'), target('select'),
      target('span', { editable: true }), target('button', { role: 'menuitem', menu: true }),
      target('button', { role: 'menuitemradio', menu: true }), target('div', { menu: true }),
      target('div', { role: 'listbox' }), target('button', { insidePlayer: false }),
      target('a', { insidePlayer: false })]) {
      for (const key of [' ', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 's', 'd']) {
        const before = { time: ui.media.currentTime, ...ui.mediaCalls };
        const { down } = press(ui, key, focused);
        assert.equal(down.defaultPrevented, false, `${focused.tagName}/${key} must retain default action`);
        assert.equal(down.propagationStopped, false);
        assert.equal(ui.media.currentTime, before.time);
        assert.equal(ui.mediaCalls.play, before.play);
        assert.equal(ui.mediaCalls.pause, before.pause);
      }
    }
    for (const modifier of ['ctrlKey', 'metaKey', 'altKey', 'shiftKey', 'isComposing']) {
      const before = { ...ui.mediaCalls };
      const { down } = press(ui, ' ', target('video'), { [modifier]: true });
      assert.equal(down.defaultPrevented, false, modifier);
      assert.deepEqual(ui.mediaCalls, before, modifier);
    }
  });
  await test('sidebar Space retains default button activation without toggling playback', async ui => {
    const before = { ...ui.mediaCalls };
    let navigations = 0;
    const { down, up } = press(ui, ' ', target('button', { insidePlayer: false }));
    if (!down.defaultPrevented && !up.defaultPrevented) navigations++;
    assert.equal(navigations, 1, 'Space must activate the focused sidebar button');
    assert.deepEqual(ui.mediaCalls, before, 'sidebar navigation must not toggle playback');
  });
  process.exitCode = failures ? 1 : 0;
})().catch(error => { console.error(error); process.exitCode = 1; });
